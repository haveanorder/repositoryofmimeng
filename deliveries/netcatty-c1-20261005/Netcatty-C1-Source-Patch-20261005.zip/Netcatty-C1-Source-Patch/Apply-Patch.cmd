@echo off
node "%~dp0apply-patch.cjs" %*
exit /b %errorlevel%
