"use strict";

const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { spawnSync } = require('node:child_process');

function main() {
  const [repository, action = 'check'] = process.argv.slice(2);
  if (!repository || !['check', 'apply', 'revert'].includes(action)) {
    throw new Error('Usage: node apply-patch.cjs "path/to/Netcatty-source" [check|apply|revert]');
  }
  const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, 'manifest.json'), 'utf8'));
  const patch = path.join(__dirname, manifest.patch.file);
  const hash = createHash('sha256').update(fs.readFileSync(patch)).digest('hex');
  if (hash !== manifest.patch.sha256) throw new Error('Patch checksum mismatch. Download the patch package again.');
  const directory = path.resolve(repository);
  function git(args) {
    const result = spawnSync('git', ['-C', directory, ...args], { encoding: 'utf8', windowsHide: true });
    if (result.error) throw result.error;
    if (result.status !== 0) throw new Error(result.stderr.trim() || `git exited with ${result.status}`);
    return result.stdout.trim();
  }
  const root = git(['rev-parse', '--show-toplevel']);
  if (fs.realpathSync(directory) !== fs.realpathSync(root)) {
    throw new Error('Choose the root directory of the Netcatty source repository.');
  }
  if (action !== 'revert' && git(['rev-parse', 'HEAD']) !== manifest.baseCommit) {
    throw new Error(`This patch requires source commit ${manifest.baseCommit}. Use a separate checkout of that commit; do not reset your existing work.`);
  }
  const flags = action === 'revert' ? ['--reverse'] : [];
  git(['apply', ...flags, '--check', patch]);
  if (action === 'check') {
    console.log('Patch is applicable. No files changed. Run again with apply to apply it.');
  } else {
    git(['apply', ...flags, patch]);
    console.log(action === 'apply' ? 'Source patch applied. Build the application using README.zh-CN.md.' : 'Source patch reverted. Installed applications and user data were not changed.');
  }
}

try { main(); } catch (error) { console.error(error.message); process.exitCode = 1; }
