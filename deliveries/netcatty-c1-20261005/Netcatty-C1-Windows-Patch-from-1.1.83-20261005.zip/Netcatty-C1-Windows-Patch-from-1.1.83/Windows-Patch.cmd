@echo off
node "%~dp0windows-patch.cjs" %*
exit /b %errorlevel%
