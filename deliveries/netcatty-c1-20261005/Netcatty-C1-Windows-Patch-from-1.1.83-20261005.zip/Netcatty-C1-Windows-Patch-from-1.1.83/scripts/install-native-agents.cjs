"use strict";
// Install official, version-pinned engines outside Netcatty's application dependencies.
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { createHash } = require('node:crypto');
const { spawn } = require('node:child_process');
const { prepareCommandForSpawn } = require('../electron/bridges/ai/shellUtils.cjs');

async function download(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${response.status} downloading ${url}`);
  return Buffer.from(await response.arrayBuffer());
}
async function main() {
  const root = path.resolve(process.argv[2] || path.join(os.homedir(), '.netcatty-native'));
  const platform = { win32: 'windows', darwin: 'darwin', linux: 'linux' }[process.platform];
  if (!platform || !['x64', 'arm64'].includes(process.arch)) throw new Error('No official OMP binary for this platform');
  const musl = platform === 'linux' && !process.report.getReport().header.glibcVersionRuntime ? '-musl' : '';
  const asset = `omp-${platform}${musl}-${process.arch}${platform === 'windows' ? '.exe' : ''}`;
  const release = 'https://github.com/can1357/oh-my-pi/releases/download/v18.6.1';
  const bin = path.join(root, 'bin', platform === 'windows' ? 'omp.exe' : 'omp');
  await fs.mkdir(path.dirname(bin), { recursive: true });
  console.log(`Installing OMP 18.6.1 (${asset}) into ${root}`);
  const checksums = (await download(`${release}/SHA256SUMS.txt`)).toString();
  const expected = checksums.split('\n').find((line) => line.trim().endsWith(` ${asset}`))?.trim().split(/\s+/)[0];
  if (!expected) throw new Error(`Official checksum not found for ${asset}`);
  let binary = await fs.readFile(bin).catch(() => null);
  if (!binary || createHash('sha256').update(binary).digest('hex') !== expected) {
    binary = await download(`${release}/${asset}`);
    if (createHash('sha256').update(binary).digest('hex') !== expected) throw new Error('OMP checksum mismatch');
    await fs.writeFile(`${bin}.download`, binary, { mode: 0o755 });
    await fs.rename(`${bin}.download`, bin);
  }
  const prefix = path.join(root, 'runtime');
  const spec = prepareCommandForSpawn(process.platform === 'win32' ? 'npm.cmd' : 'npm', [
    'install', '--prefix', prefix, '--no-audit', '--no-fund', '--save-exact',
    '@earendil-works/pi-coding-agent@1.0.2', '@deepseek-ai/dsh@0.2.1-alpha.1',
  ], { unwrapNativeExe: false });
  await new Promise((resolve, reject) => {
    const child = spawn(spec.command, spec.args, { shell: spec.shell, stdio: 'inherit', windowsHide: true });
    child.once('error', reject);
    child.once('exit', (code) => code === 0 ? resolve() : reject(new Error(`npm exited ${code}`)));
  });
  const suffix = process.platform === 'win32' ? '.cmd' : '';
  const installed = { omp: bin, pi: path.join(prefix, 'node_modules/.bin', `pi${suffix}`), dsh: path.join(prefix, 'node_modules/.bin', `dsh${suffix}`) };
  await fs.writeFile(path.join(root, 'engines.json'), JSON.stringify(installed, null, 2));
  console.log('Enter these paths in Settings > AI, configure a model/credentials, then Check CLI and save:');
  console.log(JSON.stringify(installed, null, 2));
}
main().catch((error) => { console.error(error.message); process.exitCode = 1; });
