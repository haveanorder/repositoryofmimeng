"use strict";

// Offline program-file update. User profiles, registry entries and global CLIs
// are outside this patch's file list.
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { gunzipSync } = require('node:zlib');
const { spawnSync } = require('node:child_process');
const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, 'manifest.json'), 'utf8'));
const [directory, action = 'check'] = process.argv.slice(2);
const buffer = Buffer.alloc(1024 * 1024);

function fileAt(root, relative) {
  const file = path.resolve(root, relative);
  if (!file.startsWith(path.resolve(root) + path.sep)) throw new Error('Invalid patch file path');
  return file;
}
function hash(file) {
  const digest = createHash('sha256');
  const fd = fs.openSync(file, 'r');
  try {
    let count;
    while ((count = fs.readSync(fd, buffer)) > 0) digest.update(buffer.subarray(0, count));
  } finally { fs.closeSync(fd); }
  return digest.digest('hex');
}
function verify(root, files) {
  for (const [name, info] of Object.entries(files)) {
    const file = fileAt(root, name);
    if (!fs.existsSync(file) || hash(file) !== info.sha256) {
      throw new Error(`Program file does not match the required version: ${name}`);
    }
  }
}
function requireClosed() {
  if (process.platform !== 'win32') return;
  const result = spawnSync('tasklist.exe', ['/FO', 'CSV', '/NH'], { encoding: 'utf8', windowsHide: true });
  if (result.error || result.status !== 0) throw new Error('Cannot check running programs. Close Netcatty and retry.');
  if (/"Netcatty(?: C1)?\.exe"/i.test(result.stdout)) {
    throw new Error('Close all Netcatty windows and quit it from the system tray before applying or rolling back.');
  }
}
function copy(source, destination) {
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.copyFileSync(source, destination);
}
function writePrepared(root, destination, change) {
  const data = gunzipSync(fs.readFileSync(fileAt(__dirname, change.payload)));
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  if (!change.ranges) {
    fs.writeFileSync(destination, data);
  } else {
    const input = fs.openSync(fileAt(root, change.path), 'r');
    const output = fs.openSync(destination, 'w');
    try {
      for (const [kind, offset, length] of change.ranges) {
        if (kind === 'insert') {
          fs.writeFileSync(output, data.subarray(offset, offset + length));
        } else if (kind === 'copy') {
          let position = offset;
          while (position < offset + length) {
            const count = fs.readSync(input, buffer, 0, Math.min(buffer.length, offset + length - position), position);
            if (!count) throw new Error('Unexpected end of original program file');
            fs.writeFileSync(output, buffer.subarray(0, count));
            position += count;
          }
        } else { throw new Error('Unknown patch operation'); }
      }
    } finally { fs.closeSync(input); fs.closeSync(output); }
  }
  if (hash(destination) !== change.after.sha256) throw new Error(`Prepared file checksum mismatch: ${change.path}`);
}
function restore(root, backup, checkCurrent) {
  for (const change of manifest.changes) {
    if (change.before && hash(fileAt(path.join(backup, 'original'), change.path)) !== change.before.sha256) {
      throw new Error(`Backup checksum mismatch: ${change.path}`);
    }
    const file = fileAt(root, change.path);
    if (checkCurrent && fs.existsSync(file)) {
      const current = hash(file);
      if (current !== change.before?.sha256 && current !== change.after?.sha256) {
        throw new Error(`File changed after patching; preserve your edits before rollback: ${change.path}`);
      }
    }
  }
  for (const change of manifest.changes) {
    const destination = fileAt(root, change.path);
    if (change.before) copy(fileAt(path.join(backup, 'original'), change.path), destination);
    else if (fs.existsSync(destination)) fs.unlinkSync(destination);
  }
  verify(root, manifest.baseline);
  fs.rmSync(backup, { recursive: true });
}
function main() {
  if (!directory || !['check', 'apply', 'rollback'].includes(action)) {
    throw new Error('Usage: node windows-patch.cjs "path/to/installed/Netcatty" [check|apply|rollback]');
  }
  const root = path.resolve(directory);
  const backup = path.join(root, '.netcatty-c1-1.1.83-backup');
  if (action === 'rollback') {
    requireClosed();
    const receipt = JSON.parse(fs.readFileSync(path.join(backup, 'receipt.json'), 'utf8'));
    if (receipt.patchId !== manifest.id) throw new Error('Backup belongs to another patch');
    console.log('Checking the backup and restoring Netcatty 1.1.83...');
    restore(root, backup, true);
    console.log('Restored Netcatty 1.1.83. User profiles and Agent installations were not changed.');
    return;
  }
  if (fs.existsSync(path.join(root, 'data'))) {
    throw new Error('This directory contains a portable data profile. Use the full C1 package in a separate directory to keep profiles isolated.');
  }
  console.log('Checking installed files against official Netcatty 1.1.83 Windows x64...');
  verify(root, manifest.baseline);
  for (const change of manifest.changes) {
    if (!change.before && fs.existsSync(fileAt(root, change.path))) {
      throw new Error(`An added file already exists; it will not be overwritten: ${change.path}`);
    }
  }
  if (action === 'check') {
    console.log('Official Netcatty 1.1.83 Windows x64 matched. No files changed. Run again with apply.');
    return;
  }
  requireClosed();
  if (fs.existsSync(backup)) throw new Error(`A previous backup exists. Use rollback first: ${backup}`);
  fs.mkdirSync(backup);
  let changing = false;
  try {
    console.log('Backing up original files and preparing C1 files. This can take a few minutes...');
    for (const change of manifest.changes) {
      if (change.before) copy(fileAt(root, change.path), fileAt(path.join(backup, 'original'), change.path));
      if (change.after) writePrepared(root, fileAt(path.join(backup, 'prepared'), change.path), change);
    }
    fs.writeFileSync(path.join(backup, 'receipt.json'), JSON.stringify({ patchId: manifest.id, from: '1.1.83', to: manifest.target.version }));
    requireClosed();
    changing = true;
    console.log('Applying the prepared program files...');
    for (const change of manifest.changes) {
      const file = fileAt(root, change.path);
      if (change.after) {
        fs.mkdirSync(path.dirname(file), { recursive: true });
        fs.renameSync(fileAt(path.join(backup, 'prepared'), change.path), file);
      } else { fs.unlinkSync(file); }
    }
    console.log('Verifying the C1 program files...');
    verify(root, manifest.target.files);
    fs.rmSync(path.join(backup, 'prepared'), { recursive: true });
    console.log(`Updated to Netcatty C1 ${manifest.target.version}. Start Netcatty.exe using your existing shortcut.`);
    console.log('C1 uses its own profile in %APPDATA%\\netcatty-c1. Your original profile is preserved.');
    console.log(`Program backup retained at: ${backup}`);
  } catch (error) {
    if (changing) {
      try { restore(root, backup, false); }
      catch (rollbackError) { throw new Error(`${error.message}\nAutomatic restore could not finish: ${rollbackError.message}\nKeep the backup: ${backup}`); }
    } else { fs.rmSync(backup, { recursive: true }); }
    throw error;
  }
}

try { main(); } catch (error) { console.error(error.message); process.exitCode = 1; }
