from pathlib import Path
import gzip, hashlib, json, struct

root = Path('/workspace/.netcatty-native/windows')
original = root / 'baseline-1.1.83'
updated = root / 'stage/release/win-unpacked'
package = Path('/workspace/deliverables/netcatty-c1-windows-patch')
(package / 'payload').mkdir(exist_ok=True)
for generated in (package / 'payload').glob('*.gz'):
    generated.unlink()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def inventory(directory):
    result = {}
    for file in directory.rglob('*'):
        if file.is_file():
            with file.open('rb') as stream:
                sha = hashlib.file_digest(stream, 'sha256').hexdigest()
            result[file.relative_to(directory).as_posix()] = {'sha256': sha, 'bytes': file.stat().st_size}
    return result

def asar_ranges(data):
    header = json.loads(data[16:16 + struct.unpack_from('<I', data, 12)[0]])
    start = 8 + struct.unpack_from('<I', data, 4)[0]
    result = []
    def walk(directory):
        for entry in directory['files'].values():
            if 'files' in entry:
                walk(entry)
            elif 'offset' in entry and not entry.get('unpacked') and entry['size']:
                result.append((start + int(entry['offset']), entry['size']))
    walk(header)
    return sorted(result)

def byte_ranges(before, after, asar=False):
    block_size = 64 * 1024
    def blocks(data):
        return asar_ranges(data) if asar else [(off, min(block_size, len(data) - off)) for off in range(0, len(data), block_size)]
    available = {(digest(before[off:off + size]), size): off for off, size in blocks(before)}
    ranges, literals = [], bytearray()
    def emit(kind, offset, size):
        if not size: return
        if ranges and ranges[-1][0] == kind and ranges[-1][1] + ranges[-1][2] == offset:
            ranges[-1][2] += size
        else:
            ranges.append([kind, offset, size])
    def insert(data):
        emit('insert', len(literals), len(data))
        literals.extend(data)
    position = 0
    for offset, size in blocks(after):
        assert offset >= position
        insert(after[position:offset])
        data = after[offset:offset + size]
        old_offset = available.get((digest(data), size))
        if old_offset is None: insert(data)
        else: emit('copy', old_offset, size)
        position = offset + size
    insert(after[position:])
    return ranges, bytes(literals)

baseline = inventory(original)
target = inventory(updated)
target['Netcatty.exe'] = target.pop('Netcatty C1.exe')
# NSIS adds elevate.exe after the canonical Windows ZIP is built. It belongs
# to the installer; preserve it when present instead of treating it as new.
target.pop('resources/elevate.exe', None)
changes = []
reused = 0
for name in sorted(baseline.keys() | target.keys()):
    before, after = baseline.get(name), target.get(name)
    if before == after: continue
    change = {'path': name, 'before': before, 'after': after}
    if after:
        data = (updated / ('Netcatty C1.exe' if name == 'Netcatty.exe' else name)).read_bytes()
        if name in ('Netcatty.exe', 'resources/app.asar'):
            change['ranges'], data = byte_ranges((original / name).read_bytes(), data, asar=name.endswith('.asar'))
            reused += sum(size for kind, _, size in change['ranges'] if kind == 'copy')
        change['payload'] = f'payload/{len(changes):03d}.gz'
        (package / change['payload']).write_bytes(gzip.compress(data, compresslevel=9, mtime=0))
    changes.append(change)

with (root / 'Netcatty-1.1.83-win-x64.zip').open('rb') as stream:
    original_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
manifest = {
    'id': 'netcatty-c1-win-x64-from-1.1.83-20261005',
    'fromVersion': '1.1.83',
    'platform': 'win32-x64',
    'sourceUrl': 'https://github.com/binaricat/Netcatty/releases/download/v1.1.83/Netcatty-1.1.83-win-x64.zip',
    'sourceArchiveSha256': original_hash,
    'baseline': baseline,
    'target': {'version': '0.0.0-c1.20261005.2', 'packageName': 'netcatty-c1', 'files': target},
    'changes': changes,
}
(package / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
cmd = package / 'Windows-Patch.cmd'
cmd.write_bytes(cmd.read_bytes().replace(b'\r\n', b'\n').replace(b'\n', b'\r\n'))
print(json.dumps({'changedFiles': len(changes), 'reusedBytes': reused, 'payloadBytes': sum(p.stat().st_size for p in (package / 'payload').iterdir()), 'sourceArchiveSha256': original_hash}), flush=True)
