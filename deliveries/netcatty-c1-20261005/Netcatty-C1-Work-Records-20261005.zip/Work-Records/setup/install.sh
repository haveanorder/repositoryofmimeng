#!/usr/bin/env bash
set -euo pipefail
# Netcatty onboarding, Debian 13 x64; Node 24.19.0/npm 11.9.0 provided by image.
# npm ci and postinstall require GitHub releases, npm registry, and official Electron headers.
cd /workspace/Netcatty
node -e 'if(Number(process.versions.node.split(".")[0])<24)throw Error("Use the prepared Node 24 runtime")'
setup_dir=/workspace/.netcatty-setup
mkdir -p "$setup_dir"/{cache,config,data,node-gyp,tmp,sysroot,apt/lists/partial,apt/cache/archives/partial}
chmod 700 "$setup_dir/tmp"
cat > "$setup_dir/env.sh" <<'ENV'
export XDG_CACHE_HOME=/workspace/.netcatty-setup/cache
export XDG_CONFIG_HOME=/workspace/.netcatty-setup/config
export XDG_DATA_HOME=/workspace/.netcatty-setup/data
export npm_config_cache=/workspace/.netcatty-setup/npm-cache
export npm_config_devdir=/workspace/.netcatty-setup/node-gyp
export ELECTRON_CACHE=/workspace/.netcatty-setup/cache/electron
export ELECTRON_BUILDER_CACHE=/workspace/.netcatty-setup/cache/electron-builder
export PATH=/workspace/.netcatty-setup/sysroot/usr/bin:$PATH
export TMPDIR=/workspace/.netcatty-setup/tmp
export NODE_USE_ENV_PROXY=1
export ELECTRON_GET_USE_PROXY=1
ENV
source "$setup_dir/env.sh"
# Keep system packages local; apt validates signed indexes and package hashes.
cat > "$setup_dir/apt/sources.list" <<'APT'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
APT
cat > "$setup_dir/apt/apt.conf" <<'APT'
Dir::Etc::parts "-";
Dir::Etc::main "-";
Dir::Etc::sourcelist "/workspace/.netcatty-setup/apt/sources.list";
Dir::Etc::sourceparts "-";
Dir::State::lists "/workspace/.netcatty-setup/apt/lists";
Dir::Cache "/workspace/.netcatty-setup/apt/cache";
APT::Get::List-Cleanup "false";
APT::Update::Error-Mode "any";
APT
APT_CONFIG="$setup_dir/apt/apt.conf" apt-get update
APT_CONFIG="$setup_dir/apt/apt.conf" apt-get -o Debug::NoLocking=true --download-only -y install xvfb fish
for deb in "$setup_dir"/apt/cache/archives/*.deb; do
  [ -e "$deb" ] || continue
  dpkg-deb -x "$deb" "$setup_dir/sysroot"
done
fish --version
xvfb-run -a sh -c 'test -n "$DISPLAY"'
# @electron/rebuild additionally writes ~/.electron-gyp and ~/.electron-rebuild-cache.
# In sandboxed agent runs, request tool escalation for npm ci if those paths are denied.
# Do not override HOME or disable artifact/signature/TLS checks.
npm ci
MOSH_BIN_RELEASE=moshcatty-0.1.8 npm run fetch:mosh:dev
ET_BIN_RELEASE=et-bin-6.2.10-1 npm run fetch:et:dev
# Equivalent production build without rewriting committed generated contract sources.
npm run check:plugin-contract
npm run build:plugin-runtime-deps
npm run build --workspace @netcatty/example-hello-plugin
npm run prebuild
./node_modules/.bin/vite build
git diff --exit-code
