# 已有 Netcatty 与 Agent 的使用方式

保留现有正式版及全局 Agent，不需要先卸载或降级。本次 C1 是增加方案 C 接入的独立预览版，已有正式版不会因为下载源码就自动获得这些功能。

共存修订版本：0.0.0-c1.20261005.1。使用独立应用包名 netcatty-c1，默认数据目录为 %APPDATA%\netcatty-c1；安装时不注册正式版的右键菜单与 URL 协议，新配置默认不接管 SSH/Telnet。不会自动复制正式版主机与聊天配置。

先在 PowerShell 核对 omp --version、pi --version、dsh --version，以及 Netcatty 关于页面中的版本。OMP 18.6.1、Pi 1.0.2、DSH 0.2.1-alpha.1 可直接在 C1 设置里填写现有 CLI 路径。其他版本需实际核对协议后再支持，不能默认“最新版”兼容。

如需独立安装已验证版本，可从源码目录运行 node scripts/install-native-agents.cjs "$env:USERPROFILE\.netcatty-native"，它使用独立目录，不改全局 npm 安装和 PATH。不要先执行 npm install -g 降级现有 Agent。

旧首发包只有独立应用显示名与安装标识，不足以保证默认 Electron 数据目录隔离。建议使用修订版；若暂用旧便携版，放入独立文件夹，并在启动前于旁边新建 data 目录。

本次仅做相关 deepLink/portableData 测试、修改文件 lint、真实 Electron 数据目录探针、Windows 重新打包与资源/归档核验。未声称已完成真实 Windows 桌面测试。
