# Netcatty 1.1.83 Windows x64：C1 Agent 功能补丁

本补丁从官方 v1.1.83（源码 `d7a0c8ed8d238dcf1c82d786da53037a1f1496b1`）移植 C1 的 OMP、Pi、DeepSeek Harness 接入。应用版本保持 1.1.83，补丁标识为 `C1-1183-20261007`。原 Netcatty.exe、快捷方式、应用身份和正常用户数据目录继续使用；不切换到 netcatty-c1。现有主机、密钥、聊天、设置以及 Codex/Claude 接入沿用原结构。

## 应用与回滚

1. 下载并完整解压 `Netcatty-1.1.83-C1-Windows-x64-Patch.zip`。
2. 完全退出 Netcatty，包括托盘进程。
3. 双击 `Patch-Netcatty.cmd`。自动识别安装目录；找不到或存在多个目录时，选择包含 Netcatty.exe 的目录。先检查，再选择应用。自定义盘符和安装位置均可。
4. 若安装目录需要管理员权限，右键这个入口，以管理员身份运行。重新通过原快捷方式启动 Netcatty。

回滚：退出 Netcatty，再运行同一入口并选回滚。原资源备份在安装目录 `.netcatty-c1-1183-backup`，请保留。回滚还原程序资源，保留当前用户数据和补丁期间产生的聊天。也可以双击 `Rollback-Netcatty.cmd`。补丁不会替你卸载或修改已有 Agent。

入口只覆盖 manifest.json 列出的 4 个应用资源；先校验官方资源，再备份。已经应用会直接提示；第三方改版或其他版本会拒绝覆盖。不要手工覆盖 payload 文件绕开备份。

## 配置三个已有 Agent

进入 **设置 → AI → Agents**，找到 Oh My Pi、Pi、DeepSeek Harness。三个首要兼容版本为 **OMP 18.5.1、Pi 1.0.3、DSH CLI 0.2.0-rc.2**，不会仅因版本字符串不同而拒绝启动。

- **CLI 可执行文件**：可留空自动发现，或填入已有 exe/cmd 的完整路径。自动检查 PATH，并查找 `%LOCALAPPDATA%\omp\omp.exe`、`%USERPROFILE%\.pi\agent\bin\pi.cmd`、`%APPDATA%\npm\dsh.cmd`。可在资源管理器复制路径；不要带外层引号。
- **本地工作目录**：填写实际存在的项目目录。这是 Agent 进程的工作目录；连接的终端或 SFTP 范围仍由当前 Netcatty 会话决定。
- **模型**：默认留空，复用 CLI 的现有 Provider、登录和模型配置。需要覆盖时填 `provider/model`。Netcatty 中其他 Agent 的全局模型不会强行覆盖这三个 CLI。
- 先点 **检查 CLI 并保存**，会真正启动并检查 RPC/桥接，显示实际版本；再点 **测试模型连接并保存**，会发送一句简短请求验证模型回复，可能产生普通模型调用费用。
- **凭据与高级配置**：可设置额外启动参数（JSON 字符串数组）、环境变量（JSON 对象）、可选 API 密钥。密钥通过 Netcatty 原有 Windows safeStorage/DPAPI 保存；未填写时继续使用 CLI 自己的认证。不会覆盖它们的登录或 Provider 文件。
- **DSH SDK profile** 默认 `sdk`，复用已有 DSH 配置，通过随补丁提供的桥接文件接入。自定义 profile 必须基于 DSH SDK，不要填写纯终端交互 profile。无需另装网关或另一套 DSH。
- **工具权限** 默认只开放当前范围内的 Netcatty 终端。需要操作本机项目时可选择“同时允许本地工作区工具并审批”。本地审批不会被 Auto 模式自动放行。OMP/Pi 可显式加入信任的扩展路径。

保存后，在终端侧栏打开 AI，选择对应 Agent，发送消息。消息、工具结果、提问及审批会出现在侧栏，停止使用现有停止入口。更换工作目录、CLI 或启动配置后建议新建聊天；同一配置下已有原生会话可以恢复。

## 简短 Windows 验收

应用前记录一台已有主机、一项密钥和一个已有聊天。应用后从原入口启动，确认它们及 Codex/Claude 设置仍在。分别选择三个已有 CLI，检查实际版本并测试模型连接，发一句消息；让 Agent 查询当前终端，再审批一次无害命令（例如 `echo C1_OK`），拒绝一次命令，在等待审批时停止，随后新建聊天或恢复一次。退出、回滚，再确认原入口和数据仍可用。

补丁不是上游官方发行版，未新增代码签名。默认复用现有配置；云模型、真实 SSH/SFTP 服务端和你的电脑上的最终体验，以这些验收步骤为准。完整实测范围见 `VALIDATION.zh-CN.md`。
