import { useCallback, useEffect, useState } from 'react';
import { nativeTaskOutput, type NativeControl, type NativeSessionSnapshot } from '../../infrastructure/ai/nativeAgents';
import { netcattyBridge } from '../../infrastructure/services/netcattyBridge';
import { stopAgentTurn } from '../../infrastructure/ai/harness/agentStop';
import { useI18n } from '../i18n/I18nProvider';

export function useNativeAgentSession(chatSessionId?: string) {
  const { t } = useI18n();
  const [snapshot, setSnapshot] = useState<NativeSessionSnapshot | null>(null);
  const [result, setResult] = useState('');
  const [error, setError] = useState('');
  const [pending, setPending] = useState('');
  useEffect(() => {
    let active = true;
    let receivedEvent = false;
    setSnapshot(null); setResult(''); setError(''); setPending('');
    if (!chatSessionId) return;
    const bridge = netcattyBridge.get();
    const update = (value: NativeSessionSnapshot) => setSnapshot((previous) => previous?.instanceId === value.instanceId && previous.seq > value.seq ? previous : value);
    const off = bridge?.onAiNativeSessionEvent?.(chatSessionId, (value) => { receivedEvent = true; if (active) update(value); });
    void bridge?.aiNativeSessionControl?.({ chatSessionId, action: 'snapshot' }).then((response) => { if (active && !receivedEvent && response.snapshot) update(response.snapshot); }).catch((cause: Error) => { if (active) setError(cause.message); });
    return () => { active = false; off?.(); };
  }, [chatSessionId]);
  const control = useCallback(async (payload: Omit<NativeControl, 'chatSessionId' | 'instanceId'>) => {
    if (!chatSessionId || !snapshot || pending) return;
    setPending(`${payload.action}:${payload.id || ''}`); setError('');
    try {
      const response = await netcattyBridge.get()?.aiNativeSessionControl?.({ ...payload, chatSessionId, instanceId: snapshot.instanceId });
      if (!response?.ok) setError(response?.error || t('ai.native.sessionChanged'));
      else if (payload.action === 'task-read') setResult(nativeTaskOutput(response.data) || t('ai.native.noOutput'));
    } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
    finally { setPending(''); }
  }, [chatSessionId, snapshot, pending, t]);
  const stop = useCallback(async () => {
    if (!chatSessionId) return;
    setPending('stop'); setError('');
    try { await stopAgentTurn({ chatSessionId, bridge: netcattyBridge.get(), backend: 'external-sdk' }); }
    catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
    finally { setPending(''); }
  }, [chatSessionId]);
  return { snapshot, result, clearResult: () => setResult(''), error, pending, control, stop };
}
