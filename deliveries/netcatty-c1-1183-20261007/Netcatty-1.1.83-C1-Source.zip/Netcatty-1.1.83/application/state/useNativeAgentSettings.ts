import { useState } from 'react';
import type { ExternalAgentConfig } from '../../infrastructure/ai/types';
import { NATIVE_AGENTS, type NativeEngine } from '../../infrastructure/ai/nativeAgents';
import { encryptField, decryptField } from '../../infrastructure/persistence/secureFieldAdapter';
import { netcattyBridge } from '../../infrastructure/services/netcattyBridge';
import { useI18n } from '../i18n/I18nProvider';

export function useNativeAgentSettings(engine: NativeEngine, config: ExternalAgentConfig | undefined, save: (config: ExternalAgentConfig) => void) {
  const { t } = useI18n();
  const [command, setCommand] = useState(config?.command || '');
  const [cwd, setCwd] = useState(config?.nativeOptions?.cwd || '');
  const [model, setModel] = useState(config?.nativeOptions?.model || '');
  const [args, setArgs] = useState(JSON.stringify(config?.args || []));
  const [profile, setProfile] = useState(config?.nativeOptions?.profile || '');
  const [localTools, setLocalTools] = useState<'disabled' | 'confirm'>(config?.nativeOptions?.localTools || 'disabled');
  const [extensions, setExtensions] = useState(config?.nativeOptions?.extensions?.join('\n') || '');
  const [env, setEnv] = useState(JSON.stringify(config?.env || {}, null, 2));
  const [keyName, setKeyName] = useState(config?.nativeOptions?.apiKeyEnv || (engine === 'dsh' ? 'DEEPSEEK_API_KEY' : 'ANTHROPIC_API_KEY'));
  const [apiKey, setApiKey] = useState('');
  const [clearKey, setClearKey] = useState(false);
  const [status, setStatus] = useState('');
  const [failed, setFailed] = useState(false);
  const [busy, setBusy] = useState(false);
  const submit = async (testModel = false) => {
    setBusy(true); setStatus(''); setFailed(false);
    try {
      const launchArgs = JSON.parse(args) as string[];
      if (!Array.isArray(launchArgs) || launchArgs.some((arg) => typeof arg !== 'string')) throw new Error(t('ai.native.invalidArgs'));
      const variables = JSON.parse(env) as Record<string, string>;
      if (!variables || typeof variables !== 'object' || Array.isArray(variables) || Object.values(variables).some((value) => typeof value !== 'string')) throw new Error(t('ai.native.invalidEnvironment'));
      const plainVariables = Object.fromEntries(await Promise.all(Object.entries(variables).map(async ([name, value]) => [name, await decryptField(value)])));
      const storedVariables = Object.fromEntries(await Promise.all(Object.entries(variables).map(async ([name, value]) => [name, /KEY|TOKEN|SECRET|PASSWORD/i.test(name) && !value.startsWith('enc:v1:') ? await encryptField(value) : value])));
      const resolved = await netcattyBridge.get()?.aiResolveCli?.({ command: engine, customPath: command || undefined, refreshShellEnv: true });
      if (!resolved?.available || !resolved.path) throw new Error(resolved?.error || t('ai.native.cliNotFound'));
      const secret = apiKey || (!clearKey && config?.apiKey ? await decryptField(config.apiKey) : '');
      const checked = await netcattyBridge.get()?.aiNativeAgentCheck?.({ engine, command: resolved.path, cwd, model, testModel,
        env: { ...plainVariables, NETCATTY_NATIVE_ARGS: JSON.stringify(launchArgs), NETCATTY_DSH_PROFILE: profile || 'sdk',
          NETCATTY_NATIVE_EXTENSIONS: JSON.stringify(extensions.split('\n').map((line) => line.trim()).filter(Boolean)), ...(secret && keyName ? { [keyName]: secret } : {}) },
      });
      if (!checked?.ok) throw new Error(checked?.error || t('ai.native.connectionFailed'));
      save({ ...config, id: `discovered_${engine}`, name: NATIVE_AGENTS[engine].name, sdkBackend: engine,
        command: resolved.path, commandSource: 'manual', cliVersion: resolved.version, enabled: true, available: true, args: launchArgs,
        env: storedVariables, apiKey: apiKey ? await encryptField(apiKey) : clearKey ? undefined : config?.apiKey,
        nativeOptions: { cwd, model, profile, localTools, extensions: extensions.split('\n').map((line) => line.trim()).filter(Boolean), apiKeyEnv: keyName },
      });
      setCommand(resolved.path); setApiKey(''); setClearKey(false);
      setStatus(t(testModel ? 'ai.native.modelConnected' : 'ai.native.saved', { version: checked.version || resolved.version || '', name: NATIVE_AGENTS[engine].name }));
    } catch (error) { setFailed(true); setStatus(error instanceof SyntaxError ? t('ai.native.invalidEnvironment') : error instanceof Error ? error.message : String(error)); }
    finally { setBusy(false); }
  };
  return { args, setArgs, profile, setProfile, command, setCommand, cwd, setCwd, model, setModel, localTools, setLocalTools, extensions, setExtensions, env, setEnv, keyName, setKeyName, apiKey, setApiKey, clearKey, setClearKey, status, failed, busy, submit };
}
